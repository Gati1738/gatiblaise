<!DOCTYPE html>
<html lang="en">

<head>
  <style>
.hero-img {
  position: relative;
  overflow: hidden;
}
.swiper-container {
  overflow: hidden;
}

.swiper-slide {
  position: relative;
}

.swiper-slide img {
  width: 100%;
  height: auto;
  object-fit: cover;
}
div
{
  text-decoration: none;
  color: black;
}
  </style>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>UENR - Library | Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.jpg" rel="icon">
  <link href="assets/img/logo.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: FlexStart
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/flexstart-bootstrap-startup-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <?php include 'header.php'; ?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up">Welcome to UENR Library</h1>
          <h2 data-aos="fade-up" data-aos-delay="400">Discover boundless knowledge, inspiration, and community at UENR Library. Immerse yourself in captivating books, digital resources, and engaging events. Step inside and let your imagination soar.</h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <div class="text-center text-lg-start">
            </div>
          </div>
        </div>
        <!--under construction-->
        <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
  <div class="swiper-container hero-carousel">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
        <img src="assets/img/vc.jpg" class="img-fluid" alt="Slide 1">
      </div>
      <div class="swiper-slide">
        <img src="assets/img/12.jpg" class="img-fluid" alt="Slide 2">
      </div>
      <div class="swiper-slide">
        <img src="assets/img/1.jpg" class="img-fluid" alt="Slide 3">
      </div>
    </div>
    <div class="swiper-pagination"></div>
  </div>
</div>

        <!-- area ended-->
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="values" class="values">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <!--<h2>Our Values</h2>-->
          <p>OUR SERVICES</p>
        </header>

        <div class="row">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Lending</h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Reference</h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Photocopy</h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="chat/index.php"><div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Ask a Librarian Service</h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Selective Dissemination of Information </h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Library Orientation/ Education</h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <img src="assets/img/qq.jpeg" class="img-fluid" alt="">
              <h3>Printing</h3>
              <p>This section keeps track of books as they are checked out, returned, and made available for loan, ensuring smooth access to a diverse range of materials for all readers.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
            <div class="box">
              <img src="assets/img/12.jpg" class="img-fluid" alt="">
              <h3>Internet Services</h3>
              <p>This section serves as a comprehensive inventory, providing easy access to the vast array of books and resources available within the library's collection, allowing users to search, discover, and locate materials efficiently.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <div class="box">
              <img src="assets/img/4.jpg" class="img-fluid" alt="">
              <h3>Current Access Service</h3>
              <p>The library user section provides a welcoming space where patrons can explore, engage, and access a wealth of resources, services, and support tailored to their needs.</p>
            </div>
          </div>

        </div>

      </div>

    </section><!-- End About Section -->

    <?php include 'contact.php'; ?>
  </main><!-- End #main -->

  <?php include 'footer.php'; ?>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <script>
  // Initialize Swiper Carousel
  var heroCarousel = new Swiper('.hero-carousel', {
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true
    }
  });
</script>


</body>

</html>