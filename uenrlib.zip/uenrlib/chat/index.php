<?php
session_start();
if (isset($_SESSION['unique_id'])) {
  header("location: users.php");
  exit();
}
?>

<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="form signup">
      <header>UENR Library ChatApp</header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="name-details">
          <div class="field input">
            <label>First Name</label>
            <input type="text" name="fname" placeholder="First name" required>
          </div>
          <div class="field input">
            <label>Last Name</label>
            <input type="text" name="lname" placeholder="Last name" required>
          </div>
        </div>
        <div class="field input">
          <label>Email Address</label>
          <input type="text" name="email" placeholder="Enter your email" required>
        </div>
        <div class="field input">
          <label>Password</label>
          <input type="password" name="password" id="password" placeholder="Enter new password" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field">
          <div class="password-strength-meter">
            <div class="meter"></div>
          </div>
          <small class="password-strength-text">Password must be alphanumeric and at least 8 characters long (e.g., Aa1)</small>
        </div>
        <div class="field image">
          <label>Select Image</label>
          <input type="file" name="image" accept="image/x-png,image/gif,image/jpeg,image/jpg" required>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Continue to Chat">
        </div>
      </form>
      <div class="link">Already signed up? <a href="login.php">Login now</a></div>
    </section>
  </div>

  <style>
    .password-strength-meter {
      height: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-top: 5px;
      overflow: hidden;
    }

    .meter {
      height: 100%;
      transition: width 0.3s;
    }

    .weak {
      background-color: red;
      width: 25%;
    }

    .medium {
      background-color: orange;
      width: 50%;
    }

    .strong {
      background-color: yellow;
      width: 75%;
    }

    .very-strong {
      background-color: limegreen;
      width: 100%;
    }
  </style>

  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/signup.js"></script>
  <script>
    const passwordField = document.getElementById("password");
    const passwordStrengthMeter = document.querySelector(".meter");
    const passwordStrengthText = document.querySelector(".password-strength-text");

    passwordField.addEventListener("input", function () {
      const password = this.value;
      if (password.length === 0) {
        passwordStrengthMeter.style.display = "none";
        passwordStrengthText.style.display = "none";
      } else {
        passwordStrengthMeter.style.display = "block";
        passwordStrengthText.style.display = "block";
        const strength = calculatePasswordStrength(password);
        const strengthPercentage = (strength / 4) * 100;
        passwordStrengthMeter.style.width = strengthPercentage + "%";
        passwordStrengthMeter.className = "meter " + getPasswordStrengthClassName(strength);
      }
    });

    passwordField.addEventListener("blur", function () {
      if (this.value.length === 0) {
        passwordStrengthMeter.style.display = "none";
        passwordStrengthText.style.display = "none";
      }
    });

    function calculatePasswordStrength(password) {
      let strength = 0;
      if (password.match(/[a-zA-Z0-9]+/)) {
        strength += 1;
      }
      if (password.match(/[~!@#$%^&*()_-]+/)) {
        strength += 1;
      }
      if (password.match(/[0-9]+/)) {
        strength += 1;
      }
      if (password.match(/[a-zA-Z]+/)) {
        strength += 1;
      }
      return strength;
    }

    function getPasswordStrengthClassName(strength) {
      switch (strength) {
        case 0:
        case 1:
          return "weak";
        case 2:
          return "medium";
        case 3:
          return "strong";
        case 4:
          return "very-strong";
      }
    }
  </script>
</body>
</html>
