<!DOCTYPE html>
<html lang="en">

<head>
  <style>
    div
    {
      color: black;
    }
  </style>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>UENR - Library | Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 
  <link href="assets/img/logo.jpg" rel="icon">
  <link href="assets/img/logo.jpg" rel="apple-touch-icon">


  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">


  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <?php include 'header.php'; ?>

  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="values" class="values">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <!--<h2>Our Values</h2>-->
          <p>E-Resources</p>
        </header>

        <div class="row">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.fao.org/agora/"><div class="box">
              <img src="assets/img/agora.jpg" class="img-fluid" alt="">
              <h3>AGORA</h3>
              <p>Agric/Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.aip.org/pubs"><div class="box">
              <img src="assets/img/aip.png" class="img-fluid" alt="">
              <h3>American Institute of Physics Journals</h3>
              <p>Applied & Multi discIplinary Physics</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.anb.org"><div class="box">
              <img src="assets/img/anb.jpeg" class="img-fluid" alt="">
              <h3>America National Biography Online</h3>
              <p>Biography</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.aps.org/"><div class="box">
              <img src="assets/img/aps.jpg" class="img-fluid" alt="">
              <h3>American Physical Society</h3>
              <p>Applied & Multi discIplinary Physics</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.birpublications.org"><div class="box">
              <img src="assets/img/bir.jpg" class="img-fluid" alt="">
              <h3>British Institute  of Radiology Journal</h3>
              <p>Medical radiology</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.cambridge.org/core"><div class="box">
              <img src="assets/img/cam.jpg" class="img-fluid" alt="">
              <h3>Cambridge University Press</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <a href="https://www.cochranelibrary.com/"><div class="box">
              <img src="assets/img/coc.jpg" class="img-fluid" alt="">
              <h3>Cochrane Library</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
            <a href="https://search.credoreference.com/"><div class="box">
              <img src="assets/img/credo.jpg" class="img-fluid" alt="">
              <h3>CREDO Reference</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://read.dukeupress.edu/journals/pages/Browse_by_Title"><div class="box">
              <img src="assets/img/duke.jpg" class="img-fluid" alt="">
              <h3>Duke University Press</h3>
              <p>Multi-disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="http://search.ebscohost.com"><div class="box">
              <img src="assets/img/EBSCO.jpg" class="img-fluid" alt="">
              <h3>EBSCO host</h3>
              <p>Multi-disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.euppublishing.com"><div class="box">
              <img src="assets/img/edin.jpg" class="img-fluid" alt="">
              <h3>Multi-disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.elgaronline.com/"><div class="box">
              <img src="assets/img/Edward.jpg" class="img-fluid" alt="">
              <h3>Edward Elgar Publishing</h3>
              <p>Multi-disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.emerald.com/insight/"><div class="box">
              <img src="assets/img/emerald.jpg" class="img-fluid" alt="">
              <h3>Emerald</h3>
              <p>Bus Administration/Management/Information Technology</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://projecteuclid.org/"><div class="box">
              <img src="assets/img/euclid.png" class="img-fluid" alt="">
              <h3>Euclid Maths & Statistics Online</h3>
              <p>Mathematics, Statistics Studies Law, History</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.geolsoc.org.uk/"><div class="box">
              <img src="assets/img/geo.jpg" class="img-fluid" alt="">
              <h3>Geological Society</h3>
              <p>Geology </p>
            </div>
          </a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.research4life.org/about/programs/hinari/"><div class="box">
              <img src="assets/img/hinari.jpg" class="img-fluid" alt="">
              <h3>HINARI</h3>
              <p>Health/Multi -disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://hstalks.com/"><div class="box">
              <img src="assets/img/hst.jpg" class="img-fluid" alt="">
              <h3>HST–Library in a digital Age</h3>
              <p>Health Sciences</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://hstalks.com/"><div class="box">
              <img src="assets/img/hst.jpg" class="img-fluid" alt="">
              <h3>HST Biomedical</h3>
              <p>The Biomedical and Life Sciences</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.elibrary.imf.org/"><div class="box">
              <img src="assets/img/IMF.jpg" class="img-fluid" alt="">
              <h3>IMF E-library</h3>
              <p>Economics, Statistics, Finance</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.iop.org/publications"><div class="box">
              <img src="assets/img/IOP.jpg" class="img-fluid" alt="">
              <h3>Institute of Physics</h3>
              <p>Physics</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.intellectbooks.com/"><div class="box">
              <img src="assets/img/intellect.png" class="img-fluid" alt="">
              <h3>Intellect Journal Collections</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.journaltocs.ac.uk/"><div class="box">
              <img src="assets/img/toc.jpg" class="img-fluid" alt="">
              <h3>Journal TOCS Premium</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.jstor.org/"><div class="box">
              <img src="assets/img/JSTORE.jpg" class="img-fluid" alt="">
              <h3>JSTOR</h3>
              <p>Economics, History &Political Science</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.liebertpub.com/"><div class="box">
              <img src="assets/img/liebert.jpg" class="img-fluid" alt="">
              <h3>Liebert Online</h3>
              <p>Language & Literature, Music, Math/Statistics & Education Biotechnology, clinical   medicine and law,Biomedical</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.nejm.org/"><div class="box">
              <img src="assets/img/england.jpg" class="img-fluid" alt="">
              <h3>New England Journal of Medicine online</h3>
              <p>Medicine</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.oaresciences.org/"><div class="box">
              <img src="assets/img/OARE.jpg" class="img-fluid" alt="">
              <h3>OARE Science</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://opg.optica.org/"><div class="box">
              <img src="assets/img/osa.jpg" class="img-fluid" alt="">
              <h3>OSA Journals</h3>
              <p>Optics and photonics</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.oup.com"><div class="box">
              <img src="assets/img/oxford.jpg" class="img-fluid" alt="">
              <h3>Oxford Journal</h3>
              <p>Multi-disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a><div class="box">
              <img src="assets/img/inegeta.png" class="img-fluid" alt="">
              <h3>Policy Press</h3>
              <p>Social science, Information technology</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://muse.jhu.edu/"><div class="box">
              <img src="assets/img/muse.jpg" class="img-fluid" alt="">
              <h3>Project MUSE Online</h3>
              <p>Humanities & Social Science</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://royalsociety.org/journals/"><div class="box">
              <img src="assets/img/royal.jpg" class="img-fluid" alt="">
              <h3>Royal Society Journals Online</h3>
              <p>Biological, physical and  philosophical Sciences</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://pubs.rsc.org/"><div class="box">
              <img src="assets/img/r_chem.jpg" class="img-fluid" alt="">
              <h3>Royal Society of Chemistry</h3>
              <p>Chemistry</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.rcpjournals.org/content/clinmedicine"><div class="box">
              <img src="assets/img/physics.jpg" class="img-fluid" alt="">
              <h3>Royal College of Physicians</h3>
              <p>Clinical medicines & Public Health</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://journals.sagepub.com/"><div class="box">
              <img src="assets/img/sage.jpg" class="img-fluid" alt="">
              <h3>Sage Journals</h3>
              <p>Humanities</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://methods.sagepub.com/"><div class="box">
              <img src="assets/img/Sage_res.jpg" class="img-fluid" alt="">
              <h3>Sage Research Methods</h3>
              <p>Social Science & Science</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.siam.org/publications/journals"><div class="box">
              <img src="assets/img/siam.jpg" class="img-fluid" alt="">
              <h3>Society for Industrial and Applied Mathematics Journal</h3>
              <p>Mathematics</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.tandfonline.com/"><div class="box">
              <img src="assets/img/tf.jpg" class="img-fluid" alt="">
              <h3>Taylor & Francis</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://www.journals.uchicago.edu/"><div class="box">
              <img src="assets/img/chicago.jpg" class="img-fluid" alt="">
              <h3>University of Chicago Press</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://online.ucpress.edu/journals"><div class="box">
              <img src="assets/img/cali.jpg" class="img-fluid" alt="">
              <h3>University of California Press</h3>
              <p>Sociology, Social,   Interaction, Human, research & Bio-ethics</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="http://onlinelibrary.wiley.com"><div class="box">
              <img src="assets/img/wiley.png" class="img-fluid" alt="">
              <h3>Wiley–Inter Science</h3>
              <p>Multi disciplinary</p>
            </div></a>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <a href="https://openknowledge.worldbank.org/home"><div class="box">
              <img src="assets/img/world_bank.jpg" class="img-fluid" alt="">
              <h3>World Bank E-library </h3>
              <p>World Bank publications</p>
            </div></a>
          </div>

        </div>

      </div>

    </section><!-- End About Section -->

    <?php include 'contact.php'; ?>
  </main><!-- End #main -->
  <?php include 'footer.php'; ?>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>



</body>

</html>