<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>UENR - Library | Staff</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.jpg" rel="icon">
  <link href="assets/img/logo.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: FlexStart
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/flexstart-bootstrap-startup-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <?php include 'header.php'; ?>


  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="values" class="values">

      <div class="container" data-aos="fade-up">

        <!-- ======= Team Section ======= -->
    <section id="team" class="team">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          
          <p>MAIN CAMPUS</p>
        </header>

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/staff/ama1.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:ama.asafu-adjaye@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Ms Mercy Ama Asafu-Adjaye</h4>
                <span>Library System Administrator</span>
                <p>"Welcome to our library's digital realm, where technology and knowledge converge. As the CTO, I'm excited to provide a seamless digital experience, connecting you to a vast collection of resources. Let's redefine learning, explore together, and embrace the future of literature."</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-1.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:harriet.attafuah@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Ms Harriet Fosua Attafuah</h4>
                <span>Librarian</span>
                <p>Welcome to our online library! Our dedicated staff is here to connect you with knowledge and recommendations, making your virtual experience enriching. Explore our collection, join our vibrant community, and unlock the magic of reading and learning.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/staff/lady_p.jpeg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:pearl.yeboah@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Mrs Pearl Owusuaa Amanquah</h4>
                <span>Secretary</span>
                <p>"Welcome to our library, where the magic of organization meets the joy of reading. As the secretary, I'm here to ensure smooth operations and assist you on your literary quest. From managing schedules to providing a warm welcome, let's embark on a delightful journey through the pages of our library's offerings."</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-3.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:ankudey.selorm@gmail.com"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>

              <div class="member-info">
                <h4>Selorm A. Ankudey</h4>
                <span>CTO</span>
                <p>"Step into our virtual library haven, where knowledge awaits. Our passionate staff is here to guide your journey, recommending books and resources that ignite your curiosity. Join our community of learners, explore our collection, and let the adventure begin!"</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-3.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:john.adamba@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>

              <div class="member-info">
                <h4>John Adamba</h4> <span>CTO</span>
                <p>"Step into our virtual library haven, where knowledge awaits. Our passionate staff is here to guide your journey, recommending books and resources that ignite your curiosity. Join our community of learners, explore our collection, and let the adventure begin!"</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-4.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:richard.aa-som@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Richard Aa-som Gu-imenga</h4>
                <span>Librarian</span>
                <p>"Welcome to our library, where knowledge reigns and curiosity thrives. As your librarian, I'm here to inspire and empower your love for reading. Join our community, explore our treasures, and let your imagination soar."</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-4.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:mary.asare@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Mrs Mary Asare</h4>
                <span>Librarian</span>
                <p>"Welcome to our library, where knowledge reigns and curiosity thrives. As your librarian, I'm here to inspire and empower your love for reading. Join our community, explore our treasures, and let your imagination soar."</p>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-4.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Ebenezer Cheremeh</h4>
                <span>Librarian</span>
                <p>"Welcome to our library, where knowledge reigns and curiosity thrives. As your librarian, I'm here to inspire and empower your love for reading. Join our community, explore our treasures, and let your imagination soar."</p>
              </div>
            </div>
          </div>

          <br>
          <br>

          <header class="section-header">
          <p>DORMAA CAMPUS</p>
        </header>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <div class="member-img">
                <img src="assets/img/team/team-4.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href="mailto:samuel.appiah@uenr.edu.gh"><i class="bi bi-envelope-fill"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Mr. Samuel Appiah Twumasi</h4>
                <span>Librarian</span>
                <p>"Welcome to our library, where knowledge reigns and curiosity thrives. As your librarian, I'm here to inspire and empower your love for reading. Join our community, explore our treasures, and let your imagination soar."</p>
              </div>
            </div>
          </div>


        </div>

      </div>

    </section><!-- End Team Section -->
      </div>

    </section><!-- End About Section -->

    <?php include 'contact.php'; ?>
  </main><!-- End #main -->

  <?php include 'footer.php'; ?>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>