<!-- ======= Header ======= -->
<header id="header" class="header fixed-top">
  <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

    <a href="index.php" class="logo d-flex align-items-center">
      <img src="assets/img/logo.jpg" alt="">
      <span>UENR Library</span>
    </a>

    <nav id="navbar" class="navbar">
      <ul>
        <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
        <li class="dropdown"><a href="#"><span>About</span> <i class="bi bi-chevron-down"></i></a>
          <ul>
            <li><a href="welcome.php">Welcome message from University Librarian</a></li>
            <li><a href="lib_guid.php">General Rules and Regulations</a></li>
          </ul>
        </li>
        <li class="dropdown"><a href="#"><span>Services</span> <i class="bi bi-chevron-down"></i></a>
          <ul>
            <li><a href="article_req_service.php">Article Request Services</a></li>
            <li><a href="chat/index.php">Ask the Librarian</a></li>
            <li><a href="#">OPAC</a></li>
            <li><a href="#">Library Database</a></li>
            <li><a href="#">Off-Campus Access(E-Resources)</a></li>
            <li><a href="#">E-Books</a></li>
          </ul>
        </li>
        <li><a class="nav-link scrollto" href="lib_guid.php">Library Guides</a></li>
        <li><a class="nav-link scrollto" href="staff.php">Staff</a></li>
        <li class="dropdown"><a href="#"><span>E-Library</span> <i class="bi bi-chevron-down"></i></a>
          <ul>
            <li><a href="#">Library Literature search form</a></li>
            <!--<li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
              <ul>
                <li><a href="#">Deep Drop Down 1</a></li>
                <li><a href="#">Deep Drop Down 2</a></li>
                <li><a href="#">Deep Drop Down 3</a></li>
                <li><a href="#">Deep Drop Down 4</a></li>
                <li><a href="#">Deep Drop Down 5</a></li>
              </ul>
            </li>-->
            <li><a href="eres.php">E-Resource</a></li>
            <li><a href="#">OPAC</a></li>
            <li><a href="#">Off-Campus Access(E-Resources)</a></li>
            <li><a href="#">E-Books</a></li>
          </ul>
        </li>

        <!--<li class="dropdown megamenu"><a href="#"><span>Mega Menu</span> <i class="bi bi-chevron-down"></i></a>
          <ul>
            <li>
              <a href="#">Column 1 link 1</a>
              <a href="#">Column 1 link 2</a>
              <a href="#">Column 1 link 3</a>
            </li>
            <li>
              <a href="#">Column 2 link 1</a>
              <a href="#">Column 2 link 2</a>
              <a href="#">Column 3 link 3</a>
            </li>
            <li>
              <a href="#">Column 3 link 1</a>
              <a href="#">Column 3 link 2</a>
              <a href="#">Column 3 link 3</a>
            </li>
            <li>
              <a href="#">Column 4 link 1</a>
              <a href="#">Column 4 link 2</a>
              <a href="#">Column 4 link 3</a>
            </li>
          </ul>
        </li>-->

        <li id="contact-link" style="display: none;"><a class="nav-link scrollto" href="#contact">Contact</a></li>
        
        <!--<li><a class="getstarted scrollto" href="#about">Get Started</a></li>-->
      </ul>
      <i class="bi bi-list mobile-nav-toggle"></i>
    </nav><!-- .navbar -->

  </div>
</header><!-- End Header -->

<script>
  window.addEventListener('DOMContentLoaded', function() {
    var currentUrl = window.location.href;
    if (currentUrl.endsWith('/index.php')) {
      var contactLink = document.getElementById('contact-link');
      if (contactLink) {
        contactLink.style.display = 'block';
      }
    }
  });
</script>
