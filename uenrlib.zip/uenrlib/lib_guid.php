<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>UENR - Library</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.jpg" rel="icon">
  <link href="assets/img/logo.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: FlexStart
  * Updated: May 30 2023 with Bootstrap v5.3.0
  * Template URL: https://bootstrapmade.com/flexstart-bootstrap-startup-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <?php include 'header.php'; ?>
    
    <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          
          <p>Library Guides</p>
        </header>

        <div class="row">
          <div class="col-lg-6">
            <!-- F.A.Q List 1-->
            <div class="accordion accordion-flush" id="faqlist1">
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                    Definition of Library Patrons (users)
                  </button>
                </h2>
                <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                  <div class="accordion-body">
                    The primary patrons of UENR Library shall comprise of the following:
                    <ul>
                    <li> Teaching Staff of UENR</li>
                    <li> Non-teaching Staff of UENR</li>
                    <li> Students of UENR</li>
                    <li> Researchers of UENR</li>
                    <li>Other Patrons (Users)</li>
                    <li> Members of the Community (External users)</li>
                  </ul>
                  </div>
                </div>
              </div>

              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                    Registration of Patrons
                  </button>
                </h2>
                <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                  <div class="accordion-body">
                    To be able to borrow a material from the library, potential patrons must be registered members of the library. Failure to register with the library shall result in the inability to borrow a library material.<br>
                    Registration Requirements
                    <br>
                    <br>
                  <ul>
                    <li>Student/Staff ID cards</li>
                    <li>Email address</li>
                    <li>Softcopy passport size picture</li>
                  </ul>
                  <br>
                  
                  Borrowing Regulations
                  Teaching Staff
                  Teaching staff have the opportunity to borrow two books for a period of two weeks. Renewable for another two (2) weeks.<br><br>

                  Non-teaching staff
                  Non-teaching staff have the opportunity to borrow a book for a period of two weeks. Renewable for another two (2) weeks<br>
                  Students<br>
                  Students have the opportunity to borrow a book for a period of two weeks. Renewable for another two (2) weeks.
                  <br><br>
                  The Community<br>
                  Members of the community have the opportunity to borrow a book for a period of two weeks provided he/she is a registered user of the library and has paid the enrolment fees necessary. An External borrower would need a registered user of the University Library


                  </div>
                </div>
              </div>

              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                    Borrowing Eqipment for an External User
                  </button>
                </h2>
                <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                  <div class="accordion-body">
                    For an external user to have the borrowing rights,<br>
                    <ul>
                    <li>He or she should submit a letter indicating his/her interest in borrowing a library material to the librarian</li>
                    <li>The letter should include the personal information of the user;</li>
                    <li>A valid ID Card and a passport size picture is required; and</li>
                    <li>A guarantor who is a staff and a registered user of the university library.</li><br>
                    Guarantor Information
                    For a staff to serve as a guarantor, he or she should provide the following;
                    <li>A letter of acceptance as a guarantor to the user;
                    <li>The letter should include the personal information (name, department, email address, phone number and a passport size picture)
                    </ul>
                    <span style="font-weight:bold;">NB:</span> The submission of the above mentioned information should be done personally by the guarantor.
                  </div>
                </div>
              </div>

              
            </div>
          </div>

          <div class="col-lg-6">

            <!-- F.A.Q List 2-->
            <div class="accordion accordion-flush" id="faqlist2">

              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-1">
                    Borrower Responsibilities
                  </button>
                </h2>
                <div id="faq2-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                  <div class="accordion-body">
                    Items checked out to a registered user of the library remains the responsibility of that individual. All eligible borrowers are expected to have their identity cards before materials could be checked out to them. Under no circumstance should a user write, mutilate or cut a library material.<br>
                    Borrowers will be held responsible for any damage caused to a library material in their custody and the appropriate sanction shall be meted out to him or her.<br><br>

                    <span style="font-weight: bold;">Renewal of Books</span><br>
                    Readers may renew a borrowed book once, with the permission of the Librarian.<br><br>

                    <span style="font-weight: bold;">Regular Books</span><br>
                    Regular books are books that can be borrowed by registered users of the library.<br><br>

                    <span style="font-weight: bold;">Reference Materials</span><br>
                    Reference materials are books that are not available for loan. These books include books marked “REF”, periodicals, reserved books, thesis, special organizations publications, and uncatalogued books. Only academic staff may borrow bound volumes of periodicals.<br><br>

                    <span style="font-weight: bold;">Over Due Books</span><br>
                    The overdue rate is subject to periodic review. The current rate is GH₵ 1.00 per book per day. No further books may be borrowed until books are returned and the fine incurred is paid.<br>

                   <span style="color:red; font-weight: bold;"> NB</span>: A user who refuses to pay his or her fine shall loose his or her borrowing privileges.<br>
                    If a library material is lost, the borrower will be billed for its replacement three times its current price.<br><br>

                    <span style="font-weight: bold;">Recall of a Loan Material</span><br>
                    Borrowed materials are subject to recall. The lending service of the library reserves the right to call for the immediate return of a loaned item before its due date and such recalls must be complied.


                  </div>
                </div>
              </div>

              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-2">
                    General Library Rules
                  </button>
                </h2>
                <div id="faq2-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                  <div class="accordion-body">
                    <ul>
                    <li> Users should observe silence always</li><br>
                    <li> No food or drink is allowed in the library</li><br>
                    <li> Books consulted should not be returned to shelves. They should be left on the tables</li><br>
                     <li> Firearms and other offensive weapons are not allowed in the library</li><br>
                     <li>    The use of mobile phones to make or receive calls in the library is prohibited</li><br>
                     <li>    No seat should be reserved for any user</li><br>
                     <li>    Any book recalled shall be returned within 72 hours or a fine will imposed after three days</li><br>
                      <li>   Library staff will inspect any item being taken out of the library</li><br>
                       <li>  Readers may not enter staff offices except by invitation</li><br>
                       <li>  No borrowing is allowed for regular students during inter-semester break</li><br>
                       <li>  All borrowed items are to be returned to the library three days before the end of every semester</li><br>
                       <li>  Failure to return all library books may result in withholding the examination results of the user</li>
                       <li>  Orderly conduct must be maintained at all times in the library</li><br>
                        <li> Users should dress decently</li><br><br>
                        <span style="font-weight:bold; color: red;">NB:</span> Flouting any of the General Rules of the Library shall result in imposing appropriate sanctions on the offender(s), including the suspension of the use of the library.<br>
                    </ul>
                    <span style="font-weight:bold; color: red;">NB:</span> The submission of the above mentioned information should be done personally by the guarantor.
                  </div>
                </div>
              </div>

              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2-content-3">
                    Library Offence and Sanction
                  </button>
                </h2>
                <div id="faq2-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist2">
                  <div class="accordion-body">
                    The following shall constitute library offences and sanctions:<br>
                    a) <span style="font-weight:bold;">Offence:</span> Failure to return borrowed book(s) and related material on or before due date.<br>
                    <span style="font-weight:bold;color: red;">Sanction:</span> The offender will be liable to pay a fine of GH¢1.00 per day up to the day the book(s) shall be returned.<br><br>
                    b) <span style="font-weight:bold;">Offence:</span> Loss or misplacement of book(s) and related materials.
                    <span style="font-weight:bold;color: red;">Sanction:</span> The offender will pay three times the current price of the book including the processing charge of GH¢100.00.<br><br>
                    c) <span style="font-weight:bold;">Offence:</span> Loss or Unlawful acquisition of library materials/stealing.<br>
                    <span style="font-weight:bold;color: red;">Sanction:</span> A report shall be made to the Vice-Chancellor and the Registrar against the offender for the appropriate sanctions to be instituted against him/her.<br><br>
                    d) <span style="font-weight:bold;">Offence:</span> Loss or Mutilation of books and related materials.
                    <span style="font-weight:bold;color: red;">Sanction:</span> A user who tears pages, section and illustrations from library materials shall be made to pay the cost of the items and also be banned from using the library.<br><br>
                    e) <span style="font-weight:bold;">Offence:</span> Loss or Failure to return books and other materials on demand. (i.e., when a book is recalled)<br><br>
                    <span style="font-weight:bold;color: red;">Sanction:</span> Offender shall loose the right to borrow any library materials.<br>
                    f) <span style="font-weight:bold;">Offence:</span> Loss or The use of mobile phones to make or receive calls in the library.<br><br>
                    <span style="font-weight:bold;color: red;">Sanction:</span> The offender’s phone shall be seized and handed over to him/her at the end of the semester OR shall be liable to pay a fine of GH¢10.00
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>

    </section><!-- End F.A.Q Section -->

    
    <!-- ======= Contact Section ======= -->
    <?php include 'contact.php'; ?>
    <!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'footer.php'; ?>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>